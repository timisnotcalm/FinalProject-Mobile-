import 'package:flutter/material.dart';

Widget makeTestableWidget({Widget child}) => MaterialApp(
  home: Material(child: child),
);
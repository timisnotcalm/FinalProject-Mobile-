import 'package:escooters/src/domain/scooter/scooter_marker.dart';
import 'package:flutter_bloc_patterns/base_list.dart';

abstract class ScooterRepository extends ListRepository<ScooterMarker> {}
